package cat.udl.eps.ed.bst;

public class Treap<Key extends Comparable<? super Key>, Value> implements Map<Key, Value> {

    private Node<Key, Value> root;

    private static class Node<Key extends Comparable<? super Key>, Value> {
        Key key;
        Value value;
        double priority;
        Node<Key, Value> left;
        Node<Key, Value> right;

        Node(Key key, Value value) {
            this.key = key;
            this.value = value;
            this.priority = Math.random();
        }
    }
    // Rotacion derecha
    private Node<Key, Value> rotateRight(Node<Key, Value> y) {
        Node<Key, Value> x = y.left;
        Node<Key, Value> T2 = x.right;

        // Perform rotation
        x.right = y;
        y.left = T2;

        return x;
    }

    // Rotacion izquierda
    private Node<Key, Value> rotateLeft(Node<Key, Value> x) {
        Node<Key, Value> y = x.right;
        Node<Key, Value> T2 = y.left;

        // Perform rotation
        y.left = x;
        x.right = T2;

        return y;
    }

    @Override
    public void put(Key key, Value value) {
        if (key == null) {
            throw new IllegalArgumentException("Key cannot be null");
        }
        root = put(root, key, value);
    }

    private Node<Key, Value> put(Node<Key, Value> node, Key key, Value value) {
        // Inserción BST
        if (node == null) {
            return new Node<>(key, value);
        }

        // Compara claves para BST
        int cmp = key.compareTo(node.key);

        if (cmp < 0) {
            node.left = put(node.left, key, value);
        } else if (cmp > 0) {
            node.right = put(node.right, key, value);
        } else {
            // Actualización del valor si eciste la clave
            node.value = value;
            return node;
        }

        // Heap.
        // Rota si la prioridad del padre es menos que la del hijo.
        if (node.left != null && node.left.priority > node.priority) {
            node = rotateRight(node);
        }
        if (node.right != null && node.right.priority > node.priority) {
            node = rotateLeft(node);
        }

        return node;
    }


    @Override
    public Value get(Key key) {
        if (key == null) {
            throw new IllegalArgumentException("Key cannot be null");
        }
        return get(root, key);
    }

    private Value get(Node<Key, Value> node, Key key) {
        // Standard BST search
        if (node == null) {
            return null;
        }

        int cmp = key.compareTo(node.key);

        if (cmp < 0) {
            return get(node.left, key);
        } else if (cmp > 0) {
            return get(node.right, key);
        } else {
            return node.value;
        }
    }
    @Override
    public short remove(Key key) {
        if (key == null) {
            throw new IllegalArgumentException("Key cannot be null");
        }
        root = remove(root, key);
        return 0;
    }

    private Node<Key, Value> remove(Node<Key, Value> node, Key key) {
        if (node == null) {
            return null;
        }

        int cmp = key.compareTo(node.key);

        if (cmp < 0) {
            node.left = remove(node.left, key);
        } else if (cmp > 0) {
            node.right = remove(node.right, key);
        } else {
            // Nodo a remover encontrado
            while (true) {
                if (node.left == null && node.right == null) {
                    return null;
                }
                if (node.right == null) {
                    node = rotateRight(node);
                }
                else if (node.left == null) {
                    node = rotateLeft(node);
                }
                else if (node.left.priority > node.right.priority) {
                    node = rotateRight(node);
                } else {
                    node = rotateLeft(node);
                }
                if (node.left == null && node.right == null) {
                    return null;
                }
            }
        }

        return node;
    }
    @Override
    public boolean containsKey(Key key) {
        if (key == null) {
            return false;
        }
        return get(key) != null;
    }

    @Override
    public boolean isEmpty() {
        return root == null;
    }

    public int height() {
        return height(root);
    }

    private int height(Node<Key, Value> node) {
        if (node == null) {
            return -1;
        }
        return 1 + Math.max(height(node.left), height(node.right));
    }
}
