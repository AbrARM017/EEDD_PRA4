package cat.udl.eps.ed.experiments;

import java.util.Collections;

import static cat.udl.eps.ed.experiments.ExperimentUtils.*;

public class Experiment2 {

    public static void main(String[] args) {
        int log = 20;
        int size = 1 << (log + 1) - 1;
        var elems = makeList(size);
        for (int i = 0; i < 100; i++) {
            Collections.shuffle(elems);
            var bst = sequentialBSTInsertions(elems);
            System.out.printf("%.2f\n", bst.height() / (double) log);
        }
    }
}
