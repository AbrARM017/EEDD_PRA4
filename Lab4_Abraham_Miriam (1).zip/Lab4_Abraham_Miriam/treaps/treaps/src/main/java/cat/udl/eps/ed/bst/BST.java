package cat.udl.eps.ed.bst;

public class BST<Key extends Comparable<? super Key>, Value> implements Map<Key, Value> {
    private Node<Key, Value> root;

    private static class Node<Key extends Comparable<? super Key>, Value> {
        Key key;
        Value value;
        Node<Key, Value> left;
        Node<Key, Value> right;

        Node(Key key, Value value) {
            this.key = key;
            this.value = value;
        }
    }

    @Override
    public void put(Key key, Value value) {
        if (key == null) {
            throw new IllegalArgumentException("Key cannot be null");
        }
        root = put(root, key, value);
    }

    private Node<Key, Value> put(Node<Key, Value> node, Key key, Value value) {
        if (node == null) {
            return new Node<>(key, value);
        }

        int cmp = key.compareTo(node.key);

        if (cmp < 0) {
            node.left = put(node.left, key, value);
        }
        else if (cmp > 0) {
            node.right = put(node.right, key, value);
        }
        else {
            node.value = value;
        }

        return node;
    }

    @Override
    public Value get(Key key) {
        if (key == null) {
            throw new IllegalArgumentException("Key cannot be null");
        }
        return get(root, key);
    }

    private Value get(Node<Key, Value> node, Key key) {
        if (node == null) {
            return null;
        }

        int cmp = key.compareTo(node.key);

        if (cmp < 0) {
            return get(node.left, key);
        }
        else if (cmp > 0) {
            return get(node.right, key);
        }
        else {
            return node.value;
        }
    }

    @Override
    public short remove(Key key) {
        if (key == null) {
            throw new IllegalArgumentException("Key cannot be null");
        }

        // Si la clave no existe, retornar 0
        if (!containsKey(key)) {
            return 0;
        }

        // Encontrar el nodo a eliminar y su padre
        Node<Key, Value> parent = null;
        Node<Key, Value> current = root;
        while (current != null && !key.equals(current.key)) {
            parent = current;
            if (key.compareTo(current.key) < 0) {
                current = current.left;
            } else {
                current = current.right;
            }
        }

        if (current == null) {
            return 0;
        }

        // Guardar el hijo derecho del nodo a eliminar
        Node<Key, Value> rightChild = current.right;

        // Si es la raíz
        if (parent == null) {
            if (rightChild != null) {
                root = rightChild;
            } else {
                root = current.left;
            }
        }
        // Si es un nodo interno
        else {
            if (parent.left == current) {
                if (rightChild != null) {
                    parent.left = rightChild;
                    // Si el nodo a eliminar tenía un hijo izquierdo, conectarlo
                    if (current.left != null) {
                        parent.left.left = current.left;
                    }
                } else {
                    parent.left = current.left;
                }
            } else {
                if (rightChild != null) {
                    parent.right = rightChild;
                    // Si el nodo a eliminar tenía un hijo izquierdo, conectarlo
                    if (current.left != null) {
                        parent.right.left = current.left;
                    }
                } else {
                    parent.right = current.left;
                }
            }
        }

        return 1;
    }

    @Override
    public boolean containsKey(Key key) {
        if (key == null) {
            return false;
        }
        return get(key) != null;
    }

    @Override
    public boolean isEmpty() {
        return root == null;
    }

    public int height() {
        return height(root);
    }

    private int height(Node<Key, Value> node) {
        if (node == null) {
            return -1;
        }
        return 1 + Math.max(height(node.left), height(node.right));
    }
}