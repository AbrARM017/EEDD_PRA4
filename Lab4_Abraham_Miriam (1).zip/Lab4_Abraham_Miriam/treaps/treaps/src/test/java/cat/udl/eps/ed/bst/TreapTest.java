package cat.udl.eps.ed.bst;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.RepeatedTest;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class TreapTest extends MapTest {

    @BeforeEach
    void createMap() {
        map = new Treap<>();
    }

    @RepeatedTest(value = 5, failureThreshold = 2)
    @DisplayName("The heigh after inserting n elements in order is less than 3 * log n")
    void testHeigh() {
        var log = 10;
        for (int i = 0; i < (1 << log); i++) {
            map.put(i, i);
        }
        var bst = (Treap<Integer, Integer>) map;
        assertTrue(bst.height() < log * 3);
    }
    /*
    @Test
    @DisplayName("Test random insertions")
     void testRandomInsertions() {
        Treap<Integer, Integer> treap = new Treap<>();
        for (int i = 0; i < 100; i++) {
            treap.put(i, i);
        }
        assertTrue(treap.height() < 10, "Treap height should remain logarithmic");
        //assertTrue(Math.log(2) / Math.log(2) * (treap.height() < 10 ? 1 : 0) == 1, "Treap height should remain logarithmic");
    }
    */
    @Test
    @DisplayName("Test key retrieval")
    void testKeyRetrieval() {
        Treap<String, Integer> treap = new Treap<>();
        treap.put("test", 42);
        assertEquals(42, treap.get("test"));
    }

    @Test
    @DisplayName("Test key removal")
    void testKeyRemoval() {
        Treap<Integer, String> treap = new Treap<>();
        treap.put(1, "0");
        assertEquals(0, treap.remove(1));
        assertNull(treap.get(1));

    // Test for only Treaps go here
    }
}
