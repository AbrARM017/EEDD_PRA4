package cat.udl.eps.ed.bst;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

public class BSTTest {
    private BST<Integer, String> bst;

    @BeforeEach
    void setUp() {
        bst = new BST<>();
    }

    @Test
    @DisplayName("Inserción de elementos en orden ascendente produce árbol degenerado")
    void testAscendingInsertion() {
        // Inserción en orden ascendente
        for (int i = 1; i <= 10; i++) {
            bst.put(i, "Value" + i);
        }

        // Verificacion altura del árbol
        assertEquals(9, bst.height(), "Árbol debe ser completamente degenerado");

        // Verificar posibles elementos recuperabeles.
        for (int i = 1; i <= 10; i++) {
            assertEquals("Value" + i, bst.get(i), "Fallo al recuperar elemento " + i);
        }
    }

    @Test
    @DisplayName("Inserción de elementos en orden descendente produce árbol degenerado")
    void testDescendingInsertion() {
        // Inserción en orden descendente
        for (int i = 10; i >= 1; i--) {
            bst.put(i, "Value" + i);
        }


        assertEquals(9, bst.height(), "Árbol debe ser completamente degenerado");

        for (int i = 1; i <= 10; i++) {
            assertEquals("Value" + i, bst.get(i), "Fallo al recuperar elemento " + i);
        }
    }

    @Test
    @DisplayName("Eliminación en árbol degenerado")
    void testRemovalInDegenerateTree() {
        // Crear árbol degenerado
        for (int i = 1; i <= 10; i++) {
            bst.put(i, "Value" + i);
        }

        // Eliminar elementos intermedios
        bst.remove(5);
        assertNull(bst.get(5), "Elemento 5 debe ser eliminado");

        // Verifica elementos accesibles
        assertEquals("Value4", bst.get(4), "Elemento 4 debe seguir existiendo");
        assertEquals("Value6", bst.get(6), "Elemento 6 debe seguir existiendo");
    }

    @Test
    @DisplayName("Rendimiento de árbol degenerado con muchos elementos")
    void testLargeUnbalancedTree() {
        // Insertar 1000 elementos en orden
        for (int i = 1; i <= 1000; i++) {
            bst.put(i, "Value" + i);
        }

        // Verifica altura
        assertEquals(999, bst.height(), "Altura para 1000 elementos debe ser 999");

        // Verifica inserciones aleatorias
        bst.put(500, "NewValue500");
        assertEquals("NewValue500", bst.get(500), "Debe poder sobreescribir valores");
    }

    @Test
    @DisplayName("Inserción de elementos duplicados")
    void testDuplicateInsertion() {
        bst.put(5, "First5");

        // Insertar elemento con nuevo valor siendo el mismo
        bst.put(5, "Updated5");

        // Verifica actualizacion del valor
        assertEquals("Updated5", bst.get(5), "Valor debe ser actualizado");
    }

    @Test
    @DisplayName("Comportamiento con elementos aleatorios")
    void testRandomInsertion() {
        // Crear lista de 100 elementos random
        List<Integer> randomElements = new ArrayList<>();
        for (int i = 1; i <= 100; i++) {
            randomElements.add(i);
        }
        Collections.shuffle(randomElements);

        // Insertar elementos en orden aleatorio
        for (Integer elem : randomElements) {
            bst.put(elem, "Value" + elem);
        }

        // Verificar que todos los elementos estén.
        for (int i = 1; i <= 100; i++) {
            assertEquals("Value" + i, bst.get(i), "Fallo al recuperar elemento " + i);
        }
    }
}
