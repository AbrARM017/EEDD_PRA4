package cat.udl.eps.ed.bst;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

abstract class MapTest {

    Map<Integer, Integer> map;

    static List<Integer> shuffledEvensFrom2(int n) {
        var list = new ArrayList<Integer>(n);
        for (int i = 1; i <= n; i++) {
            list.add(i * 2);
        }
        Collections.shuffle(list);
        return list;
    }

    @Test
    @DisplayName("isEmpty / put / containsKey / get are coherent")
    void testPutAndGet() {
        var evens = shuffledEvensFrom2(1000);
        assertTrue(map.isEmpty());
        for (var i: evens) {
            map.put(i, i);
        }
        assertFalse(map.isEmpty());
        // We have inserted 2, 4, 6, ..., 2000
        for (var i: evens) {
            // we can find all of them in the map
            assertTrue(map.containsKey(i));
            // we get the value we put
            assertEquals(i, map.get(i));
        }
        for (int i = 1; i <= 2001; i += 2) {
            // note that we test numbers not in the map considering
            // numbers lower than the minimum (2), between the min and the max,
            // and higher than the maximum (2000)
            // the map does not contain the odd numbers
            assertFalse(map.containsKey(i));
            // we cannot find them
            assertNull(map.get(i));
        }
    }

}